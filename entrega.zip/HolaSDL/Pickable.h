#pragma once
#ifndef PICKABLE_H
#define PICKABLE_H
#include "checkML.h"

#include "SceneObject.h"
#include "GameState.h"

class Pickable : public SceneObject {
public:
    Pickable(GameState* game, Texture* text, Vector2D<int> pos);
    virtual ~Pickable() = default;

    // M�todo para manejar la colisi�n con Mario
    virtual Collision Hit(const SDL_Rect& rectDeAtaque, Collision::Target target) override;

protected:
    virtual void triggerAction() = 0;
};

#endif


