#pragma once
#include "checkML.h"

#include "Texture.h"
#include "SceneObject.h"
#include "Game.h"
#include "GameState.h"
#include "EventHandler.h"

class Player : public SceneObject, public EventHandler
{
public:
	enum MarioState {
		BASE_MARIO,
		SUPER_MARIO,
		MARIO_FIRE
	};

	struct Anim {
		int firstFrame;
		int lastFrame;
	};

	struct PlayerAnims {
		Anim runAnim;
		int jumpFrame;
	};

	Player(Texture* text, Vector2D<int> pos, GameState* game, int livs, bool movR, MarioState marioState);
	Player(const Player& other); // Constructor por copia
	~Player();

	void Render() const override;
	void Update() override;
	Collision Hit(const SDL_Rect& rectDeAtaque, Collision::Target target) override;
	SceneObject* Clone() const override;

	void handleEvent(const SDL_Event& evento) override;
	void HandleAnims();
	void ChangeMarioState(MarioState newState);
	void resetPosition();

	//Getters
	int GetVidas() const;
private:
	const int PLAYERSPEED = 10;
	const int JUMP_POWER = 25;

	int _lives;						// Numero de vidas de Mario
	int _playerFrame;				// Indica el frame que se renderiza

	Point2D<int> _originalPos;

	enum AnimationState {
		STOPPED,
		MOVING_R,
		MOVING_L,
		AN_JUMPING,
	};

	AnimationState _animationState = STOPPED;
	MarioState _marioState = BASE_MARIO;
	PlayerAnims _playerAnims;
};

